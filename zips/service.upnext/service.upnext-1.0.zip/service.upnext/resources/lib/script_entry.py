# -*- coding: utf-8 -*-
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/gpl-2.0.txt)
"""This is the UpNext script entry point"""

from __future__ import absolute_import, division, unicode_literals

import sys

import script

script.run(sys.argv)
